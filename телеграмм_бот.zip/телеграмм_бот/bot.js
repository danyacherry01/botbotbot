const { Telegraf } = require('telegraf');
const sqlite3 = require('sqlite3').verbose();
const bot = new Telegraf('7660437300:AAEbWifDsAoWidUAntXrRrKSZF6no-38AaU');  

// Удаление вебхука и запуск бота
bot.telegram.deleteWebhook().then(() => {
    console.log("Webhook deleted");
});

// Подключение к базе данных
let db = new sqlite3.Database('./shop.db', (err) => {
    if (err) {
        console.error("Ошибка подключения к базе данных:", err.message);
    } else {
        console.log("База данных подключена.");
    }
});

// Функция для проверки и добавления колонки, если её нет
function addPhotoColumnIfNotExists() {
    db.all("PRAGMA table_info(users);", (err, columns) => {
        if (err) {
            console.error("Ошибка при проверке таблицы users:", err.message);
            return;
        }

        const columnExists = columns.some(column => column.name === "photo");

        if (!columnExists) {
            db.run("ALTER TABLE users ADD COLUMN photo NVARCHAR(255);", (err) => {
                if (err) {
                    console.error("Ошибка при добавлении колонки photo:", err.message);
                } else {
                    console.log("Колонка photo успешно добавлена.");
                }
            });
        } else {
            console.log("Колонка photo уже существует.");
        }
    });
}

// Инициализация базы данных
function initializeDatabase() {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        user_id INTEGER UNIQUE,
        first_name TEXT,
        last_name TEXT,
        username TEXT,
        email TEXT,
        phone TEXT,
        referral_code TEXT,
        referred_by TEXT,
        discount INTEGER DEFAULT 0,
        photo NVARCHAR(255)  -- Колонка photo создается при создании таблицы
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        name TEXT,
        price INTEGER,
        quantity INTEGER,
        available INTEGER
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS order_history (
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        order_date TEXT,
        total_price INTEGER,
        delivery_method TEXT,
        items TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS referrals (
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        referred_user_id INTEGER,
        reward INTEGER,
        date TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        product_id INTEGER,
        review_text TEXT,
        created_at TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS coupons (
        id INTEGER PRIMARY KEY,
        code TEXT,
        discount INTEGER,
        is_active INTEGER
    )`);
}

// Инициализация базы данных
initializeDatabase();

// Проверяем и добавляем колонку photo, если её нет
addPhotoColumnIfNotExists();


bot.start((ctx) => {
    const userId = ctx.from.id;
    const firstName = ctx.from.first_name;
    const startPayload = ctx.startPayload; // Параметр `start` из реферальной ссылки

    const dbCallback = (err) => {
        if (err) {
            console.error("Ошибка при добавлении пользователя:", err.message);
            ctx.reply("Произошла ошибка при обработке регистрации.");
        } else {
            ctx.reply("Вы успешно зарегистрированы!");
        }
    };

    if (startPayload) {
        // Пользователь зашел по реферальной ссылке
        db.get("SELECT user_id FROM users WHERE referral_code = ?", [startPayload], (err, row) => {
            if (err) {
                console.error("Ошибка при обработке реферального кода:", err.message);
                ctx.reply("Произошла ошибка при обработке реферальной ссылки.");
            } else if (row) {
                const referrerId = row.user_id;

                // Сохраняем информацию о пригласившем, если пользователь еще не существует
                db.get("SELECT * FROM users WHERE user_id = ?", [userId], (err, userRow) => {
                    if (err) {
                        console.error("Ошибка при поиске пользователя:", err.message);
                    } else if (!userRow) {
                        db.run("BEGIN TRANSACTION;", (err) => {
                            if (err) {
                                console.error("Ошибка начала транзакции:", err.message);
                            } else {
                                db.run(
                                    "INSERT INTO users (user_id, referred_by, first_name) VALUES (?, ?, ?)",
                                    [userId, referrerId, firstName],
                                    (err) => {
                                        if (err) {
                                            console.error("Ошибка при сохранении информации о приглашении:", err.message);
                                        } else {
                                            ctx.reply("Спасибо за регистрацию по реферальной ссылке!");
                                        }
                                    }
                                );
                                db.run("COMMIT;", dbCallback);
                            }
                        });
                    } else {
                        // Если пользователь уже существует, ничего не делаем
                        ctx.reply("Вы уже зарегистрированы.");
                    }
                });
            } else {
                ctx.reply("Реферальный код не найден.");
            }
        });
    } else {
        // Обычный старт без реферальной ссылки
        db.get("SELECT * FROM users WHERE user_id = ?", [userId], (err, userRow) => {
            if (err) {
                console.error("Ошибка при поиске пользователя:", err.message);
            } else if (!userRow) {
                db.run("BEGIN TRANSACTION;", (err) => {
                    if (err) {
                        console.error("Ошибка начала транзакции:", err.message);
                    } else {
                        db.run(
                            "INSERT INTO users (user_id, first_name) VALUES (?, ?)",
                            [userId, firstName],
                            (err) => {
                                if (err) {
                                    console.error("Ошибка при добавлении пользователя:", err.message);
                                } else {
                                    ctx.reply("Вы успешно зарегистрированы!");
                                }
                            }
                        );
                        db.run("COMMIT;", dbCallback);
                    }
                });
            } else {
                ctx.reply("Вы уже зарегистрированы.");
            }
        });
    }



        // Основное приветственное сообщение
        ctx.reply(`Добро пожаловать, ${firstName}! Для доступа к функциям бота, используйте меню ниже 👇`, {
            reply_markup: {
                keyboard: [
                    [
                        { text: '🛍️ Каталог товаров' },
                        { text: '🛒 Моя корзина' },
                    ],
                    [
                        { text: '📜 История покупок' },
                        { text: '👤 Мой аккаунт' }
                    ],
                    [
                        { text: '🔗 Реферальная программа' },
                        { text: '❌ Закрыть меню' }
                    ]
                ],
                resize_keyboard: true
            }
        });

        // Проверяем и добавляем пользователя, если его нет
        db.get("SELECT * FROM users WHERE user_id = ?", [userId], (err, row) => {
            if (err) {
                console.error("Ошибка при поиске пользователя:", err.message);
            } else if (!row) {
                const referralCode = generateReferralCode();
                db.run(
                    `INSERT INTO users (user_id, first_name, last_name, username, referral_code) VALUES (?, ?, ?, ?, ?)`,
                    [userId, firstName, ctx.from.last_name || '', ctx.from.username || '', referralCode],
                    (err) => {
                        if (err) {
                            console.error("Ошибка при добавлении пользователя:", err.message);
                        }
                    }
                );
            }
        });
    });


   // Реферальная программа
bot.hears('🔗 Реферальная программа', (ctx) => {
    const userId = ctx.from.id;

    db.get("SELECT referral_code, referred_by FROM users WHERE user_id = ?", [userId], (err, row) => {
        if (err) {
            console.error("Ошибка получения реферального кода:", err.message);
            ctx.reply("Не удалось загрузить реферальную программу.");
        } else {
            const referralCode = row ? row.referral_code : generateReferralCode();

            if (!row) {
                db.run("UPDATE users SET referral_code = ? WHERE user_id = ?", [referralCode, userId], (err) => {
                    if (err) {
                        console.error("Ошибка сохранения реферального кода:", err.message);
                    }
                });
            }

            // Генерация ссылки для приглашения с реферальным кодом
            const referralLink = `https://t.me/FitWayAlmaty_bot?start=referral_code=${referralCode}`;

            ctx.reply(`Ваш реферальный код: ${referralCode}\n\nПриглашайте друзей, отправив им эту ссылку:\n${referralLink}\n\nПолучайте бонусы за приглашения!`);
        }
    });
});

// Использование реферального кода
bot.hears(/Применить реферальный код (.+)/, (ctx) => {
    const userId = ctx.from.id;
    const referralCode = ctx.match[1].toUpperCase();

    db.get("SELECT * FROM users WHERE referral_code = ?", [referralCode], (err, row) => {
        if (err) {
            console.error("Ошибка при применении реферального кода:", err.message);
            ctx.reply("Ошибка при обработке реферального кода.");
        } else if (!row) {
            ctx.reply("Некорректный или несуществующий реферальный код.");
        } else {
            db.get("SELECT * FROM users WHERE user_id = ?", [userId], (err, user) => {
                if (err) {
                    console.error("Ошибка при поиске пользователя:", err.message);
                    ctx.reply("Не удалось найти ваш аккаунт.");
                    return;
                }

                if (user && user.referred_by) {
                    ctx.reply("Вы уже использовали реферальный код.");
                } else {
                    // Применяем реферальный код
                    db.run("UPDATE users SET referred_by = ? WHERE user_id = ?", [referralCode, userId], (err) => {
                        if (err) {
                            console.error("Ошибка при применении реферального кода:", err.message);
                            ctx.reply("Ошибка при применении реферального кода.");
                        } else {
                            // Начисление бонуса для пользователя
                            const bonus = 100;  // Пример бонуса
                            db.run("UPDATE users SET discount = discount + ? WHERE user_id = ?", [bonus, userId], (err) => {
                                if (err) {
                                    console.error("Ошибка при начислении бонуса:", err.message);
                                } else {
                                    ctx.reply(`Вы успешно применили реферальный код! Ваш бонус: ${bonus}₽`);
                                }
                            });
                        }
                    });
                }
            });
        }
    });
});

// Обработчик регистрации нового пользователя с реферальным кодом
bot.hears(/Регистрация по ссылке (\S+)/, (ctx) => {
    const referralCode = ctx.match[1].toUpperCase();
    const userId = ctx.from.id;

    // Проверка, существует ли реферальный код
    db.get("SELECT * FROM users WHERE referral_code = ?", [referralCode], (err, row) => {
        if (err) {
            console.error("Ошибка при регистрации пользователя:", err.message);
            ctx.reply("Ошибка при регистрации.");
        } else if (!row) {
            ctx.reply("Некорректный или несуществующий реферальный код.");
        } else {
            // Добавление нового пользователя
            const referralCode = generateReferralCode();
            db.run("INSERT INTO users (user_id, referral_code) VALUES (?, ?)", [userId, referralCode], (err) => {
                if (err) {
                    console.error("Ошибка при добавлении нового пользователя:", err.message);
                    ctx.reply("Ошибка при добавлении пользователя.");
                } else {
                    // Применение реферального кода для нового пользователя
                    db.run("UPDATE users SET referred_by = ? WHERE user_id = ?", [referralCode, userId], (err) => {
                        if (err) {
                            console.error("Ошибка при применении реферального кода:", err.message);
                            ctx.reply("Ошибка при применении реферального кода.");
                        } else {
                            ctx.reply(`Вы успешно зарегистрировались по реферальному коду!`);
                        }
                    });
                }
            });
        }
    });
});

    bot.hears('📜 История покупок', (ctx) => {
        const userId = ctx.from.id;
        let message = "Ваша история покупок:\n\n";

        db.all("SELECT * FROM order_history WHERE user_id = ?", [userId], (err, rows) => {
            if (err) {
                console.error("Ошибка получения истории покупок:", err.message);
                ctx.reply("Не удалось загрузить историю покупок.");
                return;
            }

            if (rows.length > 0) {
                rows.forEach((order, index) => {
                    const items = order.items.split(',').join('\n');
                    message += `📅 Дата: ${order.order_date}\n💰 Общая сумма: ${order.total_price}₽\n🛍️ Товары:\n${items}\n\n`;
                });

                ctx.reply(message, {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔙 Назад', callback_data: 'main_menu' }]
                        ]
                    }
                });
            } else {
                message = "У вас нет покупок.";
                ctx.reply(message, {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔙 Назад', callback_data: 'main_menu' }]
                        ]
                    }
                });
            }
        });
    });

    let cart = {};
    // Просмотр каталога товаров
bot.hears('🛍️ Каталог товаров', (ctx) => {
    let message = "📋 **Доступные товары:**\n";
    let keyboard = [];

    db.all("SELECT * FROM products WHERE available = 1", [], (err, rows) => {
        if (err) {
            console.error("Ошибка получения товаров:", err.message);
            ctx.reply("❌ **Не удалось загрузить каталог товаров. Попробуйте позже.**");
            return;
        }

        if (rows.length > 0) {
            rows.forEach((product) => {
                message += `\n🔹 **${product.name}** - ${product.price}₽ (В наличии: ${product.quantity})`;
                keyboard.push([
                    { text: `➕ Добавить ${product.name}`, callback_data: `add_${product.id}` },
                    { text: `❌ Удалить ${product.name}`, callback_data: `remove_${product.id}` }
                ]);
            });
        } else {
            message += "\n⚠️ **Каталог пуст.**";
        }

        keyboard.push([{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]);

        ctx.reply(message, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    });
});

// Добавление товара в корзину
bot.action(/add_(\d+)/, (ctx) => {
    const productId = parseInt(ctx.match[1]);
    const userId = ctx.from.id;

    db.get("SELECT * FROM products WHERE id = ?", [productId], (err, product) => {
        if (err || !product) {
            console.error("Ошибка получения товара:", err.message);
            ctx.reply("❌ **Ошибка при добавлении товара в корзину. Попробуйте позже.**");
            return;
        }

        if (product.quantity <= 0) {
            return ctx.reply(`❌ **Извините, товар "${product.name}" закончился.**`);
        }

        if (!cart[userId]) {
            cart[userId] = [];
        }

        // Добавляем товар в корзину
        cart[userId].push(product);

        // Уменьшаем количество товара в базе
        db.run("UPDATE products SET quantity = quantity - 1 WHERE id = ?", [productId], (err) => {
            if (err) {
                console.error("Ошибка при обновлении количества товара:", err.message);
                return ctx.reply("❌ **Ошибка при обновлении данных товара. Попробуйте позже.**");
            }
        });

        ctx.reply(`✅ **${product.name}** добавлен в вашу корзину!`);
    });
});

// Удаление товара из корзины
bot.action(/remove_(\d+)/, (ctx) => {
    const productId = parseInt(ctx.match[1]);
    const userId = ctx.from.id;

    const productIndex = cart[userId]?.findIndex(item => item.id === productId);

    if (productIndex === -1 || productIndex === undefined) {
        return ctx.reply("❌ **Товар не найден в вашей корзине.**");
    }

    const product = cart[userId].splice(productIndex, 1)[0];

    // Восстанавливаем количество товара в базе
    db.run("UPDATE products SET quantity = quantity + 1 WHERE id = ?", [productId], (err) => {
        if (err) {
            console.error("Ошибка при восстановлении количества товара:", err.message);
            return ctx.reply("❌ **Ошибка при обновлении данных товара. Попробуйте позже.**");
        }
    });

    ctx.reply(`❌ **${product.name}** удален из вашей корзины.`);
});

// Просмотр корзины
bot.hears('🛒 Моя корзина', (ctx) => {
    const userId = ctx.from.id;

    if (!cart[userId] || cart[userId].length === 0) {
        return ctx.reply("❌ **Ваша корзина пуста. Добавьте товары, чтобы оформить заказ.**", {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]
                ]
            }
        });
    }

    const cartItems = cart[userId]
        .map((product, index) => `${index + 1}. **${product.name}** - ${product.price}₽`)
        .join("\n");
    const totalPrice = cart[userId].reduce((sum, product) => sum + product.price, 0);

    const message = `🛒 **Ваша корзина:**\n\n${cartItems}\n\n**Итоговая стоимость:** ${totalPrice}₽`;

    ctx.reply(message, {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🛍️ Оформить заказ', callback_data: 'checkout' }],
                [{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]
            ]
        }
    });
});

// Оформление заказа с выбором метода доставки
bot.action('checkout', (ctx) => {
    const userId = ctx.from.id;

    if (!cart[userId] || cart[userId].length === 0) {
        return ctx.reply("❌ **Ваша корзина пуста. Добавьте товары, чтобы оформить заказ.**", {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]
                ]
            }
        });
    }

    const totalPrice = cart[userId].reduce((sum, product) => sum + product.price, 0);
    const items = cart[userId].map(product => product.name).join(", ");
    const orderDate = new Date().toISOString();

    const deliveryKeyboard = [
        [{ text: '🚚 Доставка на дом', callback_data: 'delivery_home' }],
        [{ text: 'Самовывоз', callback_data: 'pickup' }],
        [{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]
    ];

    ctx.reply(
        `🛒 **Ваш заказ:**\n\n**Итоговая стоимость:** ${totalPrice}₽\n**Товары:** ${items}\n\nВыберите метод доставки:`,
        {
            reply_markup: {
                inline_keyboard: deliveryKeyboard
            }
        }
    );
});

// Выбор метода доставки
bot.action('delivery_home', (ctx) => {
    const userId = ctx.from.id;
    const totalPrice = cart[userId].reduce((sum, product) => sum + product.price, 0);
    const items = cart[userId].map(product => product.name).join(", ");
    const orderDate = new Date().toISOString();

    db.run(
        `INSERT INTO order_history (user_id, order_date, total_price, delivery_method, items) 
        VALUES (?, ?, ?, ?, ?)`,
        [userId, orderDate, totalPrice, 'Доставка на дом', items],
        (err) => {
            if (err) {
                console.error("Ошибка при оформлении заказа:", err.message);
                return ctx.reply("❌ **Произошла ошибка при оформлении заказа. Пожалуйста, попробуйте позже.**");
            }

            // Очищаем корзину после успешного оформления заказа
            cart[userId] = [];

            ctx.reply(
                `🎉 **Ваш заказ успешно оформлен!**\n\n**Итоговая стоимость:** ${totalPrice}₽\n**Метод доставки:** Доставка на дом`,
                {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
        }
    );
});

// Выбор метода самовывоза
bot.action('pickup', (ctx) => {
    const userId = ctx.from.id;
    const totalPrice = cart[userId].reduce((sum, product) => sum + product.price, 0);
    const items = cart[userId].map(product => product.name).join(", ");
    const orderDate = new Date().toISOString();

    db.run(
        `INSERT INTO order_history (user_id, order_date, total_price, delivery_method, items) 
        VALUES (?, ?, ?, ?, ?)`,
        [userId, orderDate, totalPrice, 'Самовывоз', items],
        (err) => {
            if (err) {
                console.error("Ошибка при оформлении заказа:", err.message);
                return ctx.reply("❌ **Произошла ошибка при оформлении заказа. Пожалуйста, попробуйте позже.**");
            }

            // Очищаем корзину после успешного оформления заказа
            cart[userId] = [];

            ctx.reply(
                `🎉 **Ваш заказ успешно оформлен!**\n\n**Итоговая стоимость:** ${totalPrice}₽\n**Метод доставки:** Самовывоз`,
                {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔙 Назад в меню', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
        }
    );
});


    
   // Функция генерации уникального номера карты
function generateCardNumber() {
    return Math.random().toString().slice(2, 14); // Простая генерация номера карты (можно улучшить)
}

// Функция генерации реферального кода
function generateReferralCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// Функции для валидации email и телефона
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function validatePhone(phone) {
    const regex = /^\+?[0-9]{10,15}$/;
    return regex.test(phone);
}

// Обработка команды "Мой аккаунт"
const userStates = {}; // Для хранения состояния пользователя
const axios = require('axios');
const fs = require('fs');
const path = require('path');

bot.hears('👤 Мой аккаунт', (ctx) => {
    const userId = ctx.from.id;

    db.get("SELECT * FROM users WHERE user_id = ?", [userId], (err, user) => {
        if (err) {
            console.error("Ошибка при получении данных пользователя:", err.message);
            ctx.reply("Не удалось загрузить информацию о вашем аккаунте.");
            return;
        }

        if (!user) {
            const registerButton = {
                text: 'Зарегистрироваться',
                callback_data: 'register'
            };

            const message = "Вы еще не зарегистрированы в системе. Пожалуйста, используйте команду /register для регистрации.";

            ctx.reply(message, {
                reply_markup: {
                    inline_keyboard: [
                        [registerButton]
                    ]
                }
            });
            return;
        }

        const message = `Ваш аккаунт:\nИмя: ${user.first_name || ''} ${user.last_name || ''}\nUsername: @${user.username || 'Не указан'}\nEmail: ${user.email || 'Не указан'}\nТелефон: ${user.phone || 'Не указан'}\nРеферальный код: ${user.referral_code}\nФото: ${user.photo ? 'Есть' : 'Отсутствует'}`;

        const settingsButton = {
            text: 'Настройки',
            callback_data: 'settings'
        };

        if (user.photo) {
            const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${user.photo}`; // Правильный путь до фото
            const localPath = path.join(__dirname, 'temp_photo.jpg'); // Путь, куда будет сохранен файл

            // Скачиваем фото на сервер
            axios({
                method: 'get',
                url: fileUrl,
                responseType: 'stream'
            })
            .then(response => {
                const writer = fs.createWriteStream(localPath);
                response.data.pipe(writer);
                writer.on('finish', () => {
                    // Отправляем фото
                    ctx.replyWithPhoto({ source: localPath }, {
                        caption: message,
                        reply_markup: {
                            inline_keyboard: [
                                [settingsButton]
                            ]
                        }
                    });
                });
            })
            .catch(error => {
                console.error('Ошибка при скачивании фото:', error.message);
                ctx.reply(message, {
                    reply_markup: {
                        inline_keyboard: [
                            [settingsButton]
                        ]
                    }
                });
            });
        } else {
            ctx.reply(message, {
                reply_markup: {
                    inline_keyboard: [
                        [settingsButton]
                    ]
                }
            });
        }
    });
});

bot.on('callback_query', (ctx) => {
    const action = ctx.callbackQuery.data;
    const userId = ctx.from.id;

    if (!userStates[userId]) {
        userStates[userId] = {}; // Инициализация объекта состояния, если его ещё нет
    }

    if (action === 'register') {
        userStates[userId].step = 'registering_name'; // Устанавливаем значение, после инициализации
        ctx.reply("Пожалуйста, введите ваше имя для регистрации:");
    }

    if (action === 'settings') {
        const settingsMenu = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Изменить имя', callback_data: 'edit_name' },
                        { text: 'Изменить email', callback_data: 'edit_email' },
                        { text: 'Изменить телефон', callback_data: 'edit_phone' },
                        { text: 'Изменить username', callback_data: 'edit_username' }
                    ],
                    [
                        { text: 'Добавить фото', callback_data: 'add_photo' },
                        { text: 'Отмена', callback_data: 'cancel_edit' }
                    ]
                ]
            }
        };
        ctx.editMessageText("Что вы хотите изменить?", settingsMenu);
    }

    if (action === 'cancel_edit') {
        delete userStates[userId];
        ctx.editMessageText("Редактирование профиля отменено.");
    }

    if (action === 'edit_name') {
        userStates[userId].step = 'editing_name';
        ctx.reply("Введите новое имя:");
    }

    if (action === 'edit_email') {
        userStates[userId].step = 'editing_email';
        ctx.reply("Введите новый email:");
    }

    if (action === 'edit_phone') {
        userStates[userId].step = 'editing_phone';
        ctx.reply("Введите новый телефон:");
    }

    if (action === 'edit_username') {
        userStates[userId].step = 'editing_username';
        ctx.reply("Введите новый username:");
    }

    if (action === 'add_photo') {
        userStates[userId].step = 'adding_photo';
        ctx.reply("Пожалуйста, отправьте ваше фото.");
    }
});

bot.on('text', (ctx) => {
    const userId = ctx.from.id;
    const state = userStates[userId];

    if (state && state.step === 'registering_name') {
        const newName = ctx.message.text.trim();
        if (!newName) {
            ctx.reply("Имя не может быть пустым. Пожалуйста, введите ваше имя.");
            return;
        }
        state.name = newName;
        state.step = 'registering_email';
        ctx.reply("Ваше имя сохранено. Теперь введите ваш email:");
    } else if (state && state.step === 'registering_email') {
        const newEmail = ctx.message.text.trim();
        if (!validateEmail(newEmail)) {
            ctx.reply("Неверный формат email. Пожалуйста, введите корректный email.");
            return;
        }
        state.email = newEmail;
        state.step = 'registering_phone';
        ctx.reply("Ваш email сохранён. Теперь введите ваш телефон:");
    } else if (state && state.step === 'registering_phone') {
        const newPhone = ctx.message.text.trim();
        if (!validatePhone(newPhone)) {
            ctx.reply("Неверный формат телефона. Пожалуйста, введите корректный телефон.");
            return;
        }
        state.phone = newPhone;

        // Генерация card_number (если это требуется)
        const cardNumber = generateCardNumber();
        state.card_number = cardNumber;

        // Генерация реферального кода
        const referralCode = generateReferralCode();
        state.referral_code = referralCode;

        // Подтверждение перед сохранением
        const confirmationMessage = `Ваши данные:\nИмя: ${state.name}\nEmail: ${state.email}\nТелефон: ${state.phone}\nНомер карты: ${cardNumber}\nРеферальный код: ${referralCode}\nПодтвердите, если данные верны. Для отмены напишите /cancel.`;
        ctx.reply(confirmationMessage);
        state.step = 'confirm_registration'; // Переход к подтверждению регистрации
    } else if (state && state.step === 'confirm_registration') {
        const confirmation = ctx.message.text.trim().toLowerCase();

        if (confirmation === 'подтвердить') {
            // Вставка в базу данных
            db.serialize(() => {
                db.run("BEGIN TRANSACTION;", (err) => {
                    if (err) {
                        console.error("Ошибка при начале транзакции:", err.message);
                        ctx.reply("Ошибка при начале транзакции.");
                        return;
                    }

                    const referredBy = state.referred_by || null; // Обработка реферального кода (если используется)
                    db.run(
                        `INSERT INTO users (user_id, first_name, last_name, email, phone, card_number, referral_code, referred_by, username, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [userId, state.name, state.last_name || '', state.email, state.phone, state.card_number, state.referral_code, referredBy, state.username || '', state.photo || null],
                        (err) => {
                            if (err) {
                                console.error("Ошибка при добавлении пользователя:", err.message);
                                ctx.reply("Ошибка при добавлении пользователя.");
                                db.run("ROLLBACK;");
                            } else {
                                ctx.reply(`Вы успешно зарегистрированы!\nВаш номер карты: ${state.card_number}`);
                                db.run("COMMIT;");
                            }
                        }
                    );
                });
            });
            delete userStates[userId];
        } else if (confirmation === '/cancel') {
            ctx.reply("Регистрация отменена.");
            delete userStates[userId];
        } else {
            ctx.reply("Некорректный ответ. Напишите 'Подтвердить' для завершения регистрации или '/cancel' для отмены.");
        }
    }
});

bot.on('photo', async (ctx) => {
    const userId = ctx.from.id;
    const state = userStates[userId];

    if (state && state.step === 'adding_photo') {
        const photo = ctx.message.photo[ctx.message.photo.length - 1];
        const fileId = photo.file_id;

        // Получаем ссылку на файл
        const file = await bot.telegram.getFile(fileId);
        const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

        // Сохраняем URL фото в состояние пользователя
        state.photo = fileUrl;

        // Сохраняем фото в базе данных
        db.run(
            "UPDATE users SET photo = ? WHERE user_id = ?",
            [fileUrl, userId],
            (err) => {
                if (err) {
                    console.error("Ошибка при обновлении фото пользователя:", err.message);
                    ctx.reply("Ошибка при загрузке фото.");
                } else {
                    ctx.reply("Фото успешно добавлено!");
                    state.step = null; // Завершаем редактирование
                }
            }
        );
    }
});

bot.launch();