const sqlite3 = require('sqlite3').verbose();

// Создание или открытие базы данных
let db = new sqlite3.Database('./shop.db', (err) => {
    if (err) {
        console.error("Ошибка открытия базы данных:", err.message);
    } else {
        console.log("База данных подключена");
    }
});

// Удаляем старую таблицу, если она существует и создаем новую
db.run(`CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    price REAL NOT NULL CHECK(price >= 0),
    available INTEGER NOT NULL CHECK(available IN (0, 1)),
    quantity INTEGER NOT NULL CHECK(quantity >= 0)
)`, (err) => {
    if (err) {
        console.error("Ошибка создания таблицы:", err.message);
    } else {
        console.log("Таблица товаров готова");

        // Добавляем индекс для ускорения поиска товаров по имени
        db.run(`CREATE INDEX IF NOT EXISTS idx_product_name ON products(name)`);

        // Добавляем товары в базу данных (с количеством 10)
        addProduct('Протеин', 1200.00, 1, 10);
        addProduct('Креатин', 800.00, 1, 10);
        addProduct('BCAA', 900.00, 1, 10);
        addProduct('Глютамин', 1500.00, 1, 10);
        addProduct('Аминокислоты', 1100.00, 1, 10);
        addProduct('Карбовые напитки', 1300.00, 1, 10);
        addProduct('Термогеник', 1800.00, 1, 10);
        addProduct('Мульти-витамины', 750.00, 1, 10);
        addProduct('Калорийные добавки', 950.00, 1, 10);
        addProduct('Протеиновый батончик', 250.00, 1, 10);
    }
});

// Функция для добавления товаров в базу данных
function addProduct(name, price, available, quantity) {
    db.get("SELECT id FROM products WHERE name = ?", [name], (err, row) => {
        if (err) {
            console.error("Ошибка при поиске товара:", err.message);
        } else {
            if (row) {
                db.run(`UPDATE products SET price = ?, available = ?, quantity = ? WHERE name = ?`, [price, available, quantity, name], function(err) {
                    if (err) {
                        console.error("Ошибка при обновлении товара:", err.message);
                    } else {
                        console.log(`Товар ${name} обновлен в базе данных`);
                    }
                });
            } else {
                db.run(`INSERT INTO products (name, price, available, quantity) VALUES (?, ?, ?, ?)`, [name, price, available, quantity], function(err) {
                    if (err) {
                        console.error("Ошибка добавления товара:", err.message);
                    } else {
                        console.log(`Товар ${name} добавлен в базу данных`);
                    }
                });
            }
        }
    });
}

// Функция для обновления количества товара после покупки
function purchaseProduct(productName, quantityToBuy) {
    // Проверяем, достаточно ли товара
    db.get("SELECT quantity FROM products WHERE name = ?", [productName], (err, row) => {
        if (err) {
            console.error("Ошибка при поиске товара:", err.message);
        } else {
            if (row) {
                // Проверяем, достаточно ли товара для покупки
                if (row.quantity >= quantityToBuy) {
                    const newQuantity = row.quantity - quantityToBuy;

                    // Обновляем количество товара в базе данных
                    db.run(`UPDATE products SET quantity = ? WHERE name = ?`, [newQuantity, productName], function(err) {
                        if (err) {
                            console.error("Ошибка при обновлении количества товара:", err.message);
                        } else {
                            console.log(`Товар ${productName} был куплен. Оставшееся количество: ${newQuantity}`);
                        }
                    });
                } else {
                    console.log(`Недостаточно товара ${productName}. Доступно: ${row.quantity}`);
                }
            } else {
                console.log(`Товар ${productName} не найден в базе данных`);
            }
        }
    });
}

// Пример использования функции покупки
purchaseProduct('Протеин', 2); // Покупаем 2 единицы Протеина

// Закрытие базы данных при завершении работы
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error("Ошибка закрытия базы данных:", err.message);
        } else {
            console.log("База данных закрыта");
        }
        process.exit(0);
    });
});
