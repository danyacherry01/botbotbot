IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='order_history' AND xtype='U')
BEGIN
    CREATE TABLE order_history (
        order_id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NOT NULL,
        order_date DATETIME NOT NULL,
        total_price INT NOT NULL,
        delivery_method NVARCHAR(255) NOT NULL,
        items NVARCHAR(MAX) NOT NULL
    );
END
