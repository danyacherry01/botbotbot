BEGIN TRANSACTION;

-- Проверка существования таблицы users
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'users')
BEGIN
    -- Если таблицы нет, создаем её
    CREATE TABLE users (
        user_id INT PRIMARY KEY IDENTITY(1,1),
        first_name NVARCHAR(255) NOT NULL,
        last_name NVARCHAR(255),
        username NVARCHAR(255),
        email NVARCHAR(255) NOT NULL UNIQUE,
        phone NVARCHAR(255) NOT NULL,
        profile_photo NVARCHAR(255), -- Столбец для фото профиля
        referral_code NVARCHAR(255),  -- Столбец для реферального кода
        referred_by NVARCHAR(255),
        discount INT DEFAULT 0 -- Начальная скидка 0
    );
END;

-- Добавление столбца profile_photo, если он не существует
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'profile_photo')
BEGIN
    ALTER TABLE users ADD profile_photo NVARCHAR(255);
END;

-- Добавление столбца referral_code, если он не существует
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'referral_code')
BEGIN
    ALTER TABLE users ADD referral_code NVARCHAR(255);
END;

-- Создание таблицы referrals, если её нет
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'referrals')
BEGIN
    CREATE TABLE referrals (
        id INT PRIMARY KEY IDENTITY(1,1),
        user_id INT NOT NULL,
        referred_user_id INT NOT NULL,
        date DATETIME DEFAULT GETDATE(),
        reward INT CHECK (reward >= 0), -- Валидация вознаграждения
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (referred_user_id) REFERENCES users(user_id)
    );
END;

-- Индексы для ускорения поиска
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_user_id' AND object_id = OBJECT_ID('referrals'))
BEGIN
    CREATE INDEX idx_user_id ON referrals(user_id);
END;

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_referred_user_id' AND object_id = OBJECT_ID('referrals'))
BEGIN
    CREATE INDEX idx_referred_user_id ON referrals(referred_user_id);
END;

-- Проверка и создание таблицы photos
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'photos')
BEGIN
    CREATE TABLE photos (
        id INT PRIMARY KEY IDENTITY(1,1),
        user_id INT NOT NULL,
        photo_path NVARCHAR(255) NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    );
END;

COMMIT;
