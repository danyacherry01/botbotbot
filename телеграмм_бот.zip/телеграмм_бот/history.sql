IF OBJECT_ID('order_history', 'U') IS NULL
BEGIN
    CREATE TABLE order_history (
        order_id INT PRIMARY KEY IDENTITY(1,1),
        user_id INT NOT NULL,
        order_date DATETIME NOT NULL,
        total_price INT NOT NULL,
        delivery_method NVARCHAR(255) NOT NULL,
        items NVARCHAR(MAX) NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    );
END
